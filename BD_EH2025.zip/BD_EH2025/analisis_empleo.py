# -*- coding: utf-8 -*-
import pyreadstat
import pandas as pd

RUTA = r"C:\Users\FTL\Documents\INVESTIGACIÓN CNPV 2024\BD_EH2025"

df, meta = pyreadstat.read_sav(RUTA + r"\EH2025_Persona.sav")
CAEB = {int(k): v for k, v in meta.variable_value_labels.get("caeb_op", {}).items()}
COBGG = {int(k): v for k, v in meta.variable_value_labels.get("cob_op", {}).items()}

cob = pd.read_csv(RUTA + r"\..\..\PDA TINGUIPAYA\BASES DE DATOS INE\Base de datos CSV\COB2023_profesiones_tecnicas_universitarias.csv",
                  sep=";", encoding="utf-8-sig").dropna(subset=["ocu_cod"])
cob["ocu_cod"] = cob["ocu_cod"].astype(str).str.strip()
sg_map = cob.set_index("ocu_cod")["sg_nombre"].to_dict()
ocu_map = cob.set_index("ocu_cod")["ocu_nombre"].to_dict()

f = df[(df["s01a_03"] >= 21) & (df["s01a_03"] <= 70)
       & (df["aestudio"] > 13) & (df["s03a_04"] != 1)].copy()
f["grado"] = f["s03a_02a"].map({71: "Tecnico Medio", 72: "Tecnico Superior",
                                73: "Licenciatura", 74: "Diplomado",
                                75: "Maestria", 76: "Doctorado"})
f["es_prof"] = f["cob_op"].isin([2, 3])
f["estado"] = f["condact"].map({1: "Ocupado", 2: "Cesante", 3: "Aspirante",
                                4: "No PEA", 5: "No PEA"})
f["ramag"] = f["caeb_op"].map(CAEB)

ocu = f[f["condact"] == 1]
sub = ocu[~ocu["es_prof"]]
ej = ocu[ocu["es_prof"]]

# --- tablas ---
res = {}
res["total"] = len(f)
res["pea"] = int(f["pea"].sum())
res["ocupados"] = len(ocu)
res["desocupados"] = int((f["condact"].isin([2, 3])).sum())
res["no_pea"] = int((f["condact"].isin([4, 5])).sum())
res["td"] = res["desocupados"] / res["pea"] * 100
res["ejercen"] = len(ej)
res["subempleo"] = len(sub)
res["sub_pct"] = len(sub) / len(ocu) * 100

g = f.groupby("grado")
por_grado = pd.DataFrame({
    "Total": g["s01a_03"].size(),
    "PEA": g["pea"].sum().astype(int),
    "Ocupados": g["condact"].apply(lambda s: (s == 1).sum()),
    "Desocupados": g["condact"].apply(lambda s: s.isin([2, 3]).sum()),
    "Ejercen": g["es_prof"].apply(lambda s: (s & (f.loc[s.index, "condact"] == 1)).sum()),
    "Subempleo": g["es_prof"].apply(lambda s: (~s & (f.loc[s.index, "condact"] == 1)).sum()),
})
por_grado["TD%"] = (por_grado["Desocupados"] / por_grado["PEA"] * 100).round(1)
por_grado["Subemp%Ocup"] = (por_grado["Subempleo"] / por_grado["Ocupados"] * 100).round(1)

# por profesion (subgrupo COB) entre quienes ejercen
ej["cob_sg"] = ej["s04b_09a_cod"].astype(str).str.strip().map(sg_map)
por_prof = ej.groupby(["cob_sg", "grado"]).size().unstack(fill_value=0)
por_prof["Total"] = por_prof.sum(axis=1)
por_prof = por_prof.sort_values("Total", ascending=False)

# ramas de refugio
ramas = sub.groupby("ramag").size().sort_values(ascending=False)

# ocupaciones de oficio (código COB con nombre si está en el diccionario, si no gran grupo)
sub2 = sub.copy()
sub2["ocu_sg"] = sub2["s04b_09a_cod"].astype(str).str.strip()
sub2["ocu_name"] = sub2["ocu_sg"].map(ocu_map)
sub2["gg"] = sub2["cob_op"].map(COBGG)
oficios_gg = sub2.groupby("gg").size().sort_values(ascending=False)
oficios_cod = sub2["ocu_sg"].value_counts().head(25)

# guardar
writer = pd.ExcelWriter(RUTA + r"\informe_empleo_profesionales.xlsx")
pd.DataFrame([res]).to_excel(writer, sheet_name="Resumen", index=False)
por_grado.to_excel(writer, sheet_name="PorGrado")
por_prof.to_excel(writer, sheet_name="PorProfesion")
ramas.rename("n").to_frame().to_excel(writer, sheet_name="RamasRefugio")
oficios_gg.rename("n").to_frame().to_excel(writer, sheet_name="OficiosRefugioGG")
oficios_cod.rename("n").to_frame().to_excel(writer, sheet_name="OficiosRefugioCod")
writer.close()

print("resumen:", res)
print("\nPOR GRADO:\n", por_grado.to_string())
print("\nTOP PROFESIONES (ejercen):\n", por_prof.head(25).to_string())
print("\nRAMAS REFUGIO:\n", ramas.head(15).to_string())
print("\nOFICIOS REFUGIO (gran grupo) TOP 20:\n", oficios_gg.head(20).to_string())
print("\nCODIGOS OFICIO TOP 20:\n", oficios_cod.to_string())
print("\nexcel guardado")