# INFORME COMPARATIVO INTEGRAL: EL MERCADO LABORAL CALIFICADO EN BOLIVIA (2006 – 2016 – 2025)

**Autor / Marco de Investigación:** Investigación Post-Censal CNPV 2024 / Diagnóstico de Empleo Profesional y Técnico  
**Fuentes Oficiales:** Instituto Nacional de Estadística (INE) – Encuestas de Hogares:
* `EH2006_Poblacion.sav` (Línea de base inicial)
* `EH2016_Personas.sav` (Hito intermedio de consolidación económica)
* `EH2025_Persona.sav` (Hito reciente reajustado con proyecciones del Censo Nacional de Población y Vivienda 2024)

---

## 1. MARCO METODOLÓGICO Y ARMONIZACIÓN DE VARIABLES

Para garantizar una comparabilidad estadística rigurosa a lo largo de las casi dos décadas de estudio, se armonizaron las variables de las tres boletas censales bajo criterios estandarizados de la Organización Internacional del Trabajo (OIT) y del INE:

* **Universo de Análisis:** Personas entre 21 y 70 años de edad, con formación técnica superior/media o universitaria completa (>13 años de estudio formal aprobados).
* **Filtros de Exclusión:** Se excluye a estudiantes con matrícula activa en el año de la encuesta y a perceptores de rentas de jubilación/inactivos permanentes, evitando distorsiones por estudio a tiempo completo o retiro.
* **Población Económicamente Activa (PEA):** Clasificada a través de `condact` en:
  * *Ocupados* (`condact == 1`)
  * *Desocupados* (Cesantes con experiencia laboral `condact == 2` + Aspirantes por primera vez `condact == 3`).
* **Subempleo por Competencias (Sobreeducación / Inadecuación Ocupacional):** Titulados ocupados cuya inserción laboral se da fuera de los grandes grupos profesionales y técnicos de la Clasificación de Ocupaciones de Bolivia (COB grandes grupos 2 y 3). Mide a quienes trabajan en comercio, transporte, talleres mecánicos, servicios personales o tareas manuales.
* **Ponderación:** Todos los valores poblacionales se expanden utilizando el factor de proyección oficial de cada base (`factor` / `Factor_Rev2025`).

---

## 2. BALANCE GENERAL: DOS DÉCADAS DE EVOLUCIÓN (2006 vs 2016 vs 2025)

| Variable Macroeconómica Laboral | Año 2006 | Año 2016 | Año 2025 (CNPV) | Variación 2006-2025 |
| :--- | :---: | :---: | :---: | :---: |
| **Muestra de profesionales en la PEA** | 1.182 | 3.714 | 5.491 | Crecimiento muestral x4.6 |
| **PEA Profesional Ponderada (Factor)** | **650.435** | **1.018.075** | **1.513.412** | **+132.7% (Se multiplicó x2.3)** |
| **Población Ocupada Ponderada** | 606.640 | 967.993 | 1.425.759 | +135.0% |
| **Población Desocupada (Cesantes + Aspirantes)** | 43.795 | 50.082 | 87.653 | Incremento absoluto |
| **Tasa de Desempleo Abierto (Ponderada)** | **6.73%** | **4.92%** | **5.79%** | Rango estable (5% - 7%) |
| *Tasa de Desempleo Abierto (Muestra directa)* | *7.02%* | *5.14%* | *6.12%* | |
| **Tasa de Subempleo por Competencias (% Ocupados)** | **37.88%** | **50.68%** | **50.12%** | **Salto estructural (+12.2 p.p.)** |
| *Tasa de Subempleo por Competencias (Muestra)* | *38.85%* | *50.89%* | *49.43%* | Consolidado en 50% |
| **Titulados que ejercen ocupación profesional/técnica** | **62.12%** | **49.32%** | **49.88%** | Caída por debajo de la mitad |
| **Mediana Salarial: Ejerciendo** | **Bs 1.845** | **Bs 4.112** | **Bs 4.765** | +158.3% (Estancamiento 2016-2025) |
| **Mediana Salarial: En Subempleo** | **Bs 1.300** | **Bs 3.031** | **Bs 3.250** | Brecha estructural |
| **Penalización Salarial por Subempleo** | **-29.5%** | **-26.3%** | **-31.8%** | Máximo castigo histórico |

![Serie Histórica 2006-2025](grafico_serie_historica_2006_2016_2025.png)

> **Hallazgo Clave de la Serie Histórica:**
> La economía boliviana ha sido capaz de incorporar al mercado de trabajo a más de **860.000 nuevos profesionales y técnicos** en 19 años. Sin embargo, no lo hizo generando puestos de alta productividad acordes a su cualificación, sino a través de un mecanismo de absorción informal: **el subempleo por competencias subió del 37.9% al 50.1%**, convirtiéndose en el rasgo permanente del mercado de trabajo.

---

## 3. LA RECONFIGURACIÓN DE LA ESTRUCTURA OCUPACIONAL (COB)

Al comparar en qué actividades económicas se desempeñan los graduados ocupados a lo largo de las tres encuestas, se evidencia un profundo cambio estructural:

| Gran Grupo Ocupacional (COB) | 2006 (% Ocupados) | 2016 (% Ocupados) | 2025 (% Ocupados) | Tendencia 20 Años |
| :--- | :---: | :---: | :---: | :---: |
| **2. Profesionales Científicos e Intelectuales** | **42.64%** | **36.41%** | **35.75%** | Reducción de 6.9 p.p. |
| **3. Técnicos de Nivel Medio y Apoyo** | **19.49%** | **12.91%** | **14.13%** | Contracción del estrato técnico formal |
| **1. Directivos y Gerentes (Público / Privado)** | **8.18%** | **7.08%** | **2.19%** | Fuerte contracción relativa |
| **5. Trabajadores de Servicios y Comercio** | **9.78%** | **14.46%** | **18.71%** | **Se duplicó (+8.9 p.p.)** |
| **7. Industria Manufacturera, Construcción y Artesanía** | **5.46%** | **10.00%** | **10.72%** | **Se duplicó (+5.3 p.p.)** |
| **8. Operadores de Maquinaria y Choferes** | **2.56%** | **4.09%** | **5.57%** | **Creció más del doble (+3.0 p.p.)** |
| **4. Empleados Administrativos / de Oficina** | 8.41% | 9.24% | 6.67% | Estable / Leve caída |
| **6. Trabajadores Agropecuarios y Pesqueros** | 1.19% | 3.23% | 3.60% | Incremento en áreas rurales |
| **9. Trabajadores No Calificados / Elementales** | 2.03% | 1.71% | 2.09% | Piso estructural |
| **0. Fuerzas Armadas y Policía** | 0.28% | 0.63% | 0.58% | Estable |

### Dinámicas Ocupacionales Destacadas:
1. **El éxodo al sector terciario informal (Comercio y Transporte):**  
   En 2006, solo el 12.3% de los titulados trabajaba en comercio o conducción de vehículos/maquinaria. Para 2025, este porcentaje escaló al **24.3% (casi 1 de cada 4 titulados en Bolivia)**.
2. **Inserción en talleres manuales y manufactura:**  
   El porcentaje de graduados insertados en tareas de manufactura, confección, talleres y construcción pasó de **5.5% a 10.7%**, reflejando que muchos egresados técnicos no encuentran empleo en industrias formales y terminan como operarios en talleres informales.

---

## 4. DINÁMICA SALARIAL: PENALIZACIÓN ECONÓMICA Y DETERIORO REAL

El análisis de ingresos medianos en moneda nacional (Bolivianos) revela tanto la penalización por sobreeducación como el comportamiento del poder adquisitivo:

| Situación del Profesional | Mediana 2006 | Mediana 2016 | Mediana 2025 | Variación Nominal 2006-2016 | Variación Nominal 2016-2025 |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Ejerciendo Profesión / Nivel Técnico** | **Bs 1.845** | **Bs 4.112** | **Bs 4.765** | +122.9% | **+15.9% (Estancamiento)** |
| **En Subempleo por Competencias** | **Bs 1.300** | **Bs 3.031** | **Bs 3.250** | +133.2% | **+7.2% (Caída real severa)** |
| **Brecha Salarial por No Ejercer** | **-Bs 545** | **-Bs 1.081** | **-Bs 1.515** | Ampliación absoluta de la brecha |
| **Penalización Porcentual** | **-29.5%** | **-26.3%** | **-31.8%** | Máximo castigo histórico |

![Brecha Salarial por Subempleo](grafico_brecha_salarial_subempleo.png)

### Interpretación Económica:
* **El costo del subempleo:** En 2025, no ejercer la carrera implica una pérdida directa de **Bs 1.515 mensuales** frente a quien sí ejerce. Percibir Bs 3.250 mensuales sitúa al profesional subempleado muy cerca de los ingresos de trabajadores sin estudios superiores.
* **El freno del salario real (2016 - 2025):** Entre 2016 y 2025, el ingreso mediano de los profesionales que ejercen subió de Bs 4.112 a Bs 4.765 (+15.9% en 9 años, a una media de apenas 1.6% anual). Dado que la inflación acumulada superó dicho margen, los profesionales en Bolivia han experimentado una **pérdida efectiva de poder adquisitivo real**.

---

## 5. BRECHAS DE GÉNERO: LA CRECIENTE VULNERABILIDAD FEMENINA

Al desglosar la información por sexo entre 2006, 2016 y 2025, emergen tendencias críticas sobre la equidad de género en el ámbito profesional:

| Año | Sexo | PEA Ponderada | Participación PEA (%) | Tasa Desempleo (%) | Tasa Subempleo Competencias (%) |
| :---: | :--- | :---: | :---: | :---: | :---: |
| **2006** | **Hombres** | 355.008 | 54.6% | **5.25%** | 43.53% |
| | **Mujeres** | 295.427 | 45.4% | **8.52%** | 30.83% |
| **2016** | **Hombres** | 560.538 | 55.1% | **4.03%** | 54.21% |
| | **Mujeres** | 457.537 | 44.9% | **6.01%** | 46.27% |
| **2025** | **Hombres** | 799.213 | 52.8% | **3.75%** | 51.70% |
| | **Mujeres** | 714.199 | **47.2%** | **8.08%** | 48.26% |

### Hallazgos de Género:
1. **Mayor presencia femenina en la masa graduada:** La participación de la mujer en la PEA calificada subió de 45.4% a **47.2%** en 2025 (más de 714.000 mujeres con título técnico o universitario activas).
2. **Disparada de la brecha de desempleo en 2025:** Mientras que el desempleo masculino calificado descendió al **3.75%**, el desempleo femenino profesional se situó en **8.08%** (más del doble que el de los hombres, con una brecha de **+4.33 puntos porcentuales**).
3. **Subempleo femenino:** Las mujeres profesionales ocupadas presentan una tasa de subempleo del **48.26%**, concentrándose mayoritariamente en el comercio minorista, secretariado y servicios personales.

---

## 6. PROTECCIÓN POR GRADO ACADÉMICO Y REFUGIO DEL TALENTO (EH 2025)

### 6.1 El Posgrado como Escudo Antisubempleo
Los datos de la Encuesta de Hogares 2025 confirman que el nivel educativo alcanzado condiciona directamente el riesgo de sobreeducación:

![Subempleo por Grado](grafico_subempleo_por_grado_2025.png)

* **Técnico Medio:** **76.7%** en subempleo (solo 23.3% ejerce en su campo).
* **Técnico Superior:** **71.8%** en subempleo.
* **Licenciatura Universitaria:** **43.5%** en subempleo y 7.0% de desempleo.
* **Diplomado:** **28.1%** en subempleo.
* **Maestría:** **16.4%** en subempleo y solo 2.1% de desempleo.
* **Doctorado (Ph.D.):** **16.7%** en subempleo.

### 6.2 Ramas Económicas de Refugio (CAEB)
¿Dónde terminan los más de 2.500 profesionales subempleados de la muestra 2025?

![Ramas de Refugio](grafico_ramas_refugio_subempleo.png)

1. **Comercio al por mayor y menor:** **31.4%** (799 casos muestrales).
2. **Industria Manufacturera:** **12.2%** (310 casos).
3. **Transporte y Almacenamiento:** **9.4%** (239 casos).
4. **Gastronomía y Alojamiento:** **7.6%** (194 casos).
5. **Administración Pública:** **7.4%** (188 casos en tareas auxiliares no profesionales).
6. **Sector Agropecuario:** **6.8%** (172 casos).
7. **Construcción:** **5.2%** (133 casos).

---

## 7. CONCLUSIONES Y PROPUESTAS DE POLÍTICA PÚBLICA (PTDI / PAD / CENSO 2024)

1. **Superar el indicador engañoso del desempleo abierto:**  
   Las autoridades y planificadores deben dejar de evaluar el mercado calificado únicamente mediante la tasa de desempleo (5.8%). La métrica prioritaria debe ser la **tasa de subempleo por competencias (50.1%)**, que refleja el subdesarrollo del aparato productivo nacional para absorber talento.
2. **Reestructuración de la Formación Técnica:**  
   El modelo actual de formación técnica media y superior en áreas comerciales (contabilidad técnica, secretariado) está colapsado (más del 70% de subempleo). Es imperativo reconvertir la oferta formativa hacia carreras técnicas vinculadas a la transición energética, agroindustria tecnificada y mantenimiento industrial especializado.
3. **Plan de Empleo Juvenil Calificado con Enfoque de Género:**  
   Dado que las mujeres profesionales sufren una tasa de desempleo que duplica a la de los hombres (8.08% vs 3.75%), los Gobiernos Autónomos Municipales y Departamentales deben incorporar cláusulas de inserción laboral femenina calificada en proyectos de inversión pública y compras estatales.
4. **Financiamiento a Posgrados Productivos:**  
   La evidencia estadística demuestra que cursar una maestría reduce el subempleo a menos del 17%. El Estado y las universidades públicas deben crear programas de financiamiento blando y becas para posgrados aplicados a la resolución de problemas productivos regionales.
