import re

RUTA = r"C:\Users\FTL\Documents\INVESTIGACIÓN CNPV 2024\BD_EH2025"
usadas = set()
for f in ["procesar_personas.py", "analisis_empleo.py", "informe_empleo.py"]:
    src = open(RUTA + "\\" + f, encoding="utf-8").read()
    for m in re.findall(r'\[["\']([a-z0-9_]+)["\']', src):
        usadas.add(m)

print("Variables referenciadas en los scripts:", len(usadas))
print(sorted(usadas))