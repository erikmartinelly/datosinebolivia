# METODOLOGÍA DE PROCESAMIENTO Y ANÁLISIS
## Separación de datos, selección de indicadores y variables descartadas — EH2025 (INE Bolivia)

**Investigación CNPV 2024 · Encuesta de Hogares 2025**
**Archivo fuente**: `EH2025_Persona.sav`
**Procesamiento**: Python 3.14 (pyreadstat, pandas)

---

## Índice

1. Objeto del documento
2. Herramientas, carga de datos y estructura del archivo
3. Proceso de separación de datos (filtros secuenciales paso a paso)
4. Selección de indicadores de empleo, desempleo y subempleo
5. Clasificación de profesiones y grados
6. Variables utilizadas (las 11 elegidas)
7. Variables descartadas y motivos (grupo por grupo)
8. Limitaciones metodológicas
9. Reproducibilidad (archivos generados)

---

## 1. Objeto del documento

Este documento explica de forma completa y auditable la metodología aplicada para:

1. Separar y depurar los microdatos de personas de la Encuesta de Hogares 2025 (INE) hasta obtener una población de **profesionales titulados**.
2. Justificar la elección de **quiné indicadores se usan** y **por qué se privilegian unos sobre otros**.
3. Detallar **qué variables del archivo se descartaron** y la razón técnica o conceptual de cada descarte.

El fin es que cualquier revisor pueda reproducir el análisis, entender las decisiones y evaluar su validez.

---

## 2. Herramientas, carga de datos y estructura del archivo

### 2.1 Lectura del archivo SPSS

La base `EH2025_Persona.sav` está en formato SPSS (extensión `.sav`). Se leyó con la librería **pyreadstat**, que es la opción estándar en Python para este formato. Elegida por encima de alternativas (p. ej. `savReaderWriter`, SPSS Statistics por ODBC) por tres razones:

- **Rendimiento**: lee archivos grandes en memoria sin exportaciones intermedias.
- **Fidelidad del diccionario**: devuelve no sólo la tabla de datos sino también los **labels de variables** (`column_names_to_labels`) y los **labels de valores** (`variable_value_labels`), es decir las etiquetas que el INE puso a cada código. Esto es imprescindible para no interpretar números a ciegas.
- **Interoperabilidad**: permite escribir de vuelta archivos `.sav` con `write_sav`, preservando etiquetas (se usó para generar las bases depuradas).

### 2.2 El problema de codificación

El diccionario original del INE está codificado en ANSI/Windows-1252; al imprimirse en consola algunos caracteres (Ñ, í, ó) aparecen distorsionados (`�`). Esto **no altera los datos**: son sólo las etiquetas legibles por humanos. Los valores numéricos subyacentes son correctos. Para los archivos de texto generados (`.md`, `.csv`) se usó `utf-8`, garantizando compatibilidad con cualquier editor.

### 2.3 Estructura del archivo original

| Característica | Valor |
|---|---|
| Número de registros (personas) | 39,485 |
| Número de variables | 276 |
| Unidad de análisis | Persona dentro de hogar |
| Carácter | Cada fila = una persona; identificador de hogar en `folio` |

Las 276 variables se agrupan en los siguientes módulos del cuestionario:

| Módulo | Prefijo | Temática |
|---|---|---|
| Identificación | `area`, `depto`, `nro`, `folio` | Ubicación y unidad muestral |
| Características generales | `s01a_*` | Sexo, edad, fecha de nacimiento, etnia, estado civil, migración |
| Migración | `s01b_*` | Lugar de residencia previo |
| Salud | `s02a_*`–`s02d_*` | Afiliación, seguro, salud reproductiva |
| Educación | `s03a_*`, `s03b_*`, `s03c_*` | Lectoescritura, nivel y curso, matrícula, uso de TIC |
| Empleo | `s04a_*`–`s04f_*` | Actividad laboral, ocupación, rama, ingresos |
| Ingresos no laborales | `s05a_*`–`s05c_*` | Rentas, bonos, remesas |
| Variables derivadas | `niv_ed`, `aestudio`, `pet`, `pea`, `pei`, `condact`, `cob_op`, `caeb_op`, `yprilab`, etc. | Cálculos del INE |

Este inventario es la base para decidir qué usar y qué descartar (sección 7).

---

## 3. Proceso de separación de datos — paso a paso

### Decisión transversal: filtros secuenciales

Los filtros se aplicaron **uno tras otro**, no en paralelo. Los motivos:

1. **Auditabilidad**: cada paso muestra cuántos registros se pierden y dónde. Es fácil verificar la coherencia (por ejemplo, que el paso de edad no descarte a quienes ya no tienen educación).
2. **Dependencia lógica**: el criterio de "título completo" (paso 4) sólo tiene sentido después de quedarse con adultos con formación superior (pasos 1–3); filtrar en otro orden no cambiaría el resultado final pero dificultaría el diagnóstico.
3. **Coherencia con variables derivadas del INE**: variables como `condact`, `pea` o `aestudio` están calculadas para todo el archivo; filtrar la población antes de usarlas conserva su definición oficial.

---

### Paso 1 — Eliminación de menores de 21 años

| Criterio | Variable | Definición oficial | Filtro |
|---|---|---|---|
| Edad mínima | `s01a_03` | "¿Cuántos años cumplidos tiene?" | `s01a_03 >= 21` |

**¿Por qué esta variable?** La edad es la única variable directa que mide madurez y trayectoria educativa esperable. `s01a_03` es una variable numérica continua, sin pérdida de información (a diferencia de rangos de edad). Tiene 99 valores posibles (0–98 años).

**¿Por qué el corte en 21?** El sistema educativo boliviano exige, como mínimo:
- 12 años de escolaridad (primaria + secundaria) para obtener el bachillerato, que normalmente se completa a los 17–18 años.
- 3 a 5 años adicionales de formación superior (técnica superior o licenciatura) para obtener un título.
Por tanto, **21 años es la edad mínima realista a la que una persona puede haber terminado una carrera superior**. Cortes alternativos fueron evaluados y rechazados:
- **18–19 años**: demasiado bajo; incluiría estudiantes activos sin título.
- **25 años**: demasiado alto; excluiría técnicos superiores (carreras de 2 años, terminadas a los 20–21) y profesionales jóvenes válidos.

Adicionalmente, la propia EH2025 define la **Población en Edad de Trabajar (PET)** a partir de los 14 años (`pet`), pero ese corte es demográfico (para el mercado laboral general), no para el análisis de titulados, de modo que se respetó el corte de 21 específico de este estudio.

**Resultado**: eliminados **14,342** registros (0–20 años). Restan **25,143**.

---

### Paso 2 — Eliminación de mayores de 70 años

| Criterio | Variable | Filtro |
|---|---|---|
| Edad máxima | `s01a_03` | `s01a_03 <= 70` |

**¿Por qué el corte en 70?**
- La EH registra personas de hasta 98 años; incluirlas mezclaría población plenamente activa con jubilados y dependería de la memoria y disponibilidad de trabajo a edades extremas.
- 70 años es un límite razonable de **participación laboral activa** para profesionales: cubre cohortes en prejubilación (60–65) que aún pueden estar plenamente ocupadas, sin arrastrar a quienes están fuera del mercado por edad avanzada.
- El análisis busca el *desajuste educativo* de población que **podría trabajar**; a partir de 70, la no participación deja de ser "subempleo" y pasa a ser "retiro legítimo".

**¿Por qué no en 65?** Aunque 65 es la edad "clásica" de jubilación, en Bolivia la jubilación es flexible y muchos profesionales (médicos, docentes, abogados) permanecen activos después de los 65. Cortar en 65 habría subestimado la oferta profesional real. Se priorizó el criterio estadístico (participación) sobre el administrativo (edad de retiro).

**Resultado**: eliminados **2,117** registros. Restan **23,026**.

---

### Paso 3 — Eliminación de personas con 13 años de educación o menos

| Criterio | Variable | Filtro | 
|---|---|---|
| Años de estudio | `aestudio` ("Años de estudio") | `aestudio > 13` |

**¿Por qué `aestudio` y no otra variable educativa?** Este fue uno de los puntos de decisión más importantes. Se evaluaron cuatro candidatas:

1. **`aestudio` (años de estudio)** — **SELECCIONADA.**
   - Escala continua (0–23 años), lo que permite un corte exacto y reproducible.
   - En el sistema boliviano, el **bachillerato completo = 12 años de estudio**. Por tanto, 13 años implican haber iniciado (aprobado al menos un año de) educación **post-secundaria**. El umbral `> 13` aísla con precisión a quienes cruzaron la frontera hacia la educación superior.
   - Su distribución es informativa (valores 14–23 en la población final), lo que además permitió validar que no hubiera pérdidas extrañas.

2. **`niv_ed` (nivel educativo detallado)** — **DESCARTADA.**
   - Variable categórica con 7 clases (Ninguno, Primaria incompleta/completa, Secundaria incompleta/completa, Superior, Otros).
   - La clase "Superior" (código 5) mezcla técnicos medios, técnicos superiores, licenciados y posgraduados, sin distinguir si el título está completo.
   - Usarla como filtro no permite separar "con iniciación superior" de "con texto completo".

3. **`niv_ed_g` (nivel educativo general)** — **DESCARTADA.**
   - Versión más agregada aún (5 clases). Pierde el detalle de la categoría "Superior" y no es apta para definir titulados.

4. **`educ_prev` (años de estudio previos)** — **DESCARTADA.**
   - Variable complementaria usada por el INE para construir `aestudio`; duplica información con menos cobertura (tiene más perdidos).

**¿Por qué el umbral ">13" y no "≥ 14" o "≥ 13"?**
- `aestudio` mide **años completados**. 13 años = bachillerato + 1 año de educación superior; 14 = +2; etc.
- El corte `>13` es el más amplio que garantiza haber **tocado** la educación superior, y fue la instrucción explícita del usuario ("quitar a los que tienen 13 años de educación o menos"). Cualquier año adicional habría sido un sesgo arbitrario hacia carreras más largas.

**Nota sobre valores faltantes**: 2,000 personas en el archivo original no tienen `aestudio` (niños de 0–3 años sin educación). Como todas quedaron descartadas en el paso 1 (edad <21), ninguna pérdida por dato faltante se produjo aquí.

**Resultado**: eliminados **14,845** registros. Restan **8,181**.

---

### Paso 4 — Eliminación de personas con grado inconcluso (matriculadas en 2025)

| Criterio | Variable | Filtro |
|---|---|---|
| Matrícula vigente | `s03a_04` ("¿Durante este año se inscribió o matriculó en algún curso o grado de educación ... superior o posgrado?") | `s03a_04 != 1` (no matriculado) |

**¿Por qué esta variable y este criterio?** La pregunta `s03a_04` detecta quién está **cursando activamente** en la gestión actual (2025). Quien se matriculó está en formación, es decir, su grado académico está **en curso / inconcluso** aunque declare un nivel aprobado. La decisión de eliminar a **todos los matriculados** fue una instrucción explícita del usuario.

**Consecuencia de la elección**: esta medida es **conservadora y simple**: no distingue casos "de refuerzo" (un licenciado que toma un curso corto). Se aceptó conscientemente, priorizando la homogeneidad del universo (sólo personas fuera del sistema educativo) sobre la inclusión máxima.

**Alternativas evaluadas y descartadas**:
1. **Quitar sólo a quienes cursen un nivel superior al aprobado** (matriculados con `s03a_06a > s03a_02a`). Igual de válida, pero introduce una comparación de niveles (71–76) más frágil y fue rechazada por el usuario, que eligió el criterio simple.
2. **Uso de `s03a_06a` (nivel al que se matriculó)** para afinar: descartada por la misma razón; sirve como diagnóstico, no como filtro.

**Resultado**: eliminados **1,759** registros. Restan **6,422 profesionales titulados**.

---

### Resumen del proceso de separación

| Paso | Acción | Variable | Eliminados | Restantes | Población resultante |
|---|---|---|---|---|---|
| 0 | Lectura original | — | — | 39,485 | Todos |
| 1 | Menores de 21 | `s01a_03` | 14,342 | 25,143 | Adultos |
| 2 | Mayores de 70 | `s01a_03` | 2,117 | 23,026 | Adultos activos |
| 3 | ≤13 años de estudio | `aestudio` | 14,845 | 8,181 | Con educación superior iniciada |
| 4 | Matriculados 2025 | `s03a_04` | 1,759 | **6,422** | **Profesionales titulados** |

---

## 4. Selección de indicadores de empleo, desempleo y subempleo

### 4.1 Condición de actividad — `condact`

**Definición oficial** (labels INE): `1 p_ocupado`, `2 p_cesante`, `3 p_aspirante`, `4 p_temporal`, `5 p_permanente`.

**¿Por qué `condact`?**
- Es la clasificación **más desagregada** de la situación laboral que ofrece la base. Cada código tiene un sentido operativo claro:
  - **1 p_ocupado**: trabajó al menos una hora o tuvo empleo en la semana de referencia → **empleado**.
  - **2 p_cesante**: trabajó antes, perdió el empleo y busca activamente → **desempleado**.
  - **3 p_aspirante**: nunca trabajó y busca por primera vez → **desempleado**.
  - **4 p_temporal / 5 p_permanente**: población fuera de la fuerza de trabajo en la semana de referencia (No PEA).

**¿Por qué sobre `pea`, `pet`, `pei`?**
- `pet` (14+ años) es un delimitador demográfico: no define estado laboral.
- `pea` es binaria (1=activo, 0=inactivo): **no distingue cesantes de aspirantes**, y por tanto no permite calcular el desempleo abierto ni sus componentes.
- `pei` sólo identifica inactivos.
- Sólo con `condact` se puede reconstruir la PEA clásica (ocupados + cesantes + aspirantes) *y* descomponerla. Las otras tres quedaron como variables de verificación (los totales coinciden: PEA = 5,491).

**Indicadores derivados**:
- PEA = Ocupados(5,155) + Cesantes(280) + Aspirantes(56) = **5,491**.
- Tasa de desempleo abierto = (280+56)/5,491 × 100 = **6,12%**.
- Tasa de ocupación = 5,155/5,491 = 93,9%.

### 4.2 Subempleo por competencias — `cob_op`

**Definición oficial** (`cob_op` = Grupo Ocupacional de la Ocupación Principal, COB 2023): 0 Fuerzas Armadas, 1 Directivos, **2 Profesionales científicos e intelectuales**, **3 Técnicos de nivel medio**, 4 Empleados de oficina, 5 Servicio y vendedores, 6 Agricultura, 7 Construcción/Manufactura, 8 Operadores de máquinas, 9 No calificados.

**¿Por qué `cob_op` es el clasificador central del subempleo?**
- El marco del estudio (las "categorías profesionales que maneja el INE para profesionales técnicos y universitarios") corresponde exactamente a los **grandes grupos 2 y 3 del COB 2023**. Es la definición oficial de "ocupación profesional/técnica".
- Por tanto, definir: **ejerce** = ocupado con `cob_op ∈ {2,3}`; **subempleo por competencias** = ocupado con `cob_op ∉ {2,3}`.
- Es el indicador que permite medir el **desajuste educativo severo**: una persona con título que ocupa un puesto de grupo 5 (vendedor) o 7 (albañil) está desaprovechada, sin importar en qué rama trabaje.

**Resultado**: de 5,155 ocupados, **2,607** ejercen y **2,548** están en subempleo (49,4%).

### 4.3 ¿Por qué no usar `caeb_op` como clasificador principal?

`caeb_op` (CAEB 2022) clasifica la **rama de actividad económica** del lugar de trabajo (Agricultura, Manufactura, Educación, Salud, etc.). Se le descartó como clasificador principal **a propósito**, porque mide *dónde* trabaja la persona, no *qué hace*. Un titulado puede:
- Trabajar en "Servicios de Educación" barriendo (ocupación no profesional) → `caeb_op` diría que está en educación (mal).
- Trabajar en "Comercio" como contador en una cooperativa (ocupación profesional) → `caeb_op` diría comercio (mal).

**Uso correcto dado**: `caeb_op` se usó como **variable complementaria** para mapear las **ramas de refugio** (sección "Rutas de pérdida de talento"), lo que sí responde a la pregunta "¿en qué sectores se hunde el talento?".

### 4.4 Rama de actividad de refugio — `caeb_op`

Para el mapa sectorial se agrupó a los 2,548 subempleados por `caeb_op`:
- Comercio (799), Manufactura (310), Transporte (239), Alojamiento/comidas (194), Adm. pública (188), etc.
Esto describe el **destino ocupacional** de los titulados desplazados, complementando al clasificador ocupacional.

### 4.5 Nivel académico — `s03a_02a`

`"s03a_02a"` ("¿Cuál fue el NIVEL Y CURSO más alto de instrucción que aprobó? Nivel") distingue: 71 Técnico Medio, 72 Técnico Superior, 73 Licenciatura, 74 Diplomado, 75 Maestría, 76 Doctorado.

**¿Por qué esta y no `niv_ed`/`niv_ed_g`?**
- `niv_ed`/`niv_ed_g` sólo dirían "Superior" (todo junto); imposible desglosar por grado.
- `aestudio` (años) seguiría funcionando, pero en tablas de grupo los rótulos "17 años" son menos legibles que "Licenciatura".
- `s03a_02a` es la variable de origen de donde el INE deriva el resto: es la más fiel al concepto "grado académico".

### 4.6 Ingreso laboral — `yprilab`

`yprilab` = "Ingreso laboral Ocupación Principal (Bs/Mes)". Es la variable derivada del INE que mensualiza el ingreso de la ocupación principal, incorporando frecuencia (mensual/quinzenal/semanal/etc.). Por eso se eligió **por encima de** `s04d_22a` (monto crudo sin frecuencia) y `s04d_22b` (frecuencia por separado).

**¿Por qué mediana y no media?** Los ingresos presentan cola derecha (valores muy altos) que inflarían la media. La mediana es robusta y típica en análisis de ingresos.

**Resultado**: mediana Bs 4,765 (ejercen) vs Bs 3,250 (subempleo) → **penalización -31,8%**.

---

## 5. Clasificación de profesiones y grados

### 5.1 El problema de la "carrera"

La base **no tiene una variable directa de carrera o título** (p. ej. "Licenciatura en Derecho", "Ingeniería Civil"). La Encuesta de Hogares no pregunta la carrera; sólo el nivel aprobado y el curso.

**Solución**: usar el **Clasificador de Ocupaciones de Bolivia (COB 2023)** (archivo de respaldo con 432 códigos de profesiones), que asigna a cada código de ocupación (`s04b_09a_cod`) su **subgrupo profesional** (ej. "Profesionales en derecho", "Profesionales de la salud"). El cruce se hace a nivel de 5 dígitos del código ocupacional.

### 5.2 Por qué el subgrupo COB y no el código a 5 dígitos

- El código a 5 dígitos (489 valores distintos) es demasiado granular para tablas legibles.
- El nivel de grupo (2–3 dígitos) agrupa ocupaciones afines en **profesiones reconocibles** (Médicos, Abogados, Profesores, etc.).
- Se eligió el nivel de **subgrupo (sg_nombre)** porque equilibra legibilidad (47 categorías) y precisión.

### 5.3 Limitación estructural del desglose por profesión

Sólo es posible clasificar por profesión a quienes **ejercen** (tienen código de ocupación profesional, grupos 2–3). Por tanto:
- Los 2,607 que ejercen → matriz por profesión y grado.
- Los 2,548 subempleados y los 336 desocupados → **no se les deduce la carrera** (su ocupación actual no la revela y la base no registra la cartera de origen). Se les caracteriza por la rama/oficio de refugio. Esta es una limitación explícita de la fuente, no una omisión.

---

## 6. Las 11 variables utilizadas

| # | Variable | Rol | Uso exacto |
|---|---|---|---|
| 1 | `s01a_03` | Filtro | Edad 21–70 |
| 2 | `s01a_02` | Clasificación | Desglose por sexo |
| 3 | `aestudio` | Filtro | >13 años de estudio |
| 4 | `s03a_04` | Filtro | No matriculado (título terminado) |
| 5 | `s03a_02a` | Clasificación | Grado académico (71–76) |
| 6 | `condact` | Indicador | Estado laboral (empleo/desempleo) |
| 7 | `pea` | Verificación | Población activa (coherencia) |
| 8 | `cob_op` | Indicador | Subempleo por competencias (grupos 2–3) |
| 9 | `caeb_op` | Complemento | Ramas de refugio / sector |
| 10 | `s04b_09a_cod` | Mapeo | Código COB detallado → profesión |
| 11 | `yprilab` | Indicador | Penalización salarial (mediana) |

Además se usó el archivo auxiliar externo `COB2023_profesiones_tecnicas_universitarias.csv` (no es variable del `.sav`) para el etiquetado de profesiones.

---

## 7. Variables descartadas y motivos

De 276 variables se usaron 11 → **265 descartadas**. Los motivos son varios: redundancia, escala errónea, nivel erróneo de agregación, cobertura incompleta, o ser ajenas al objeto de estudio. Se documentan por módulo.

### 7.1 Identificación y diseño muestral
| Variable | Motivo |
|---|---|
| `folio`, `nro` | Identificadores; no aportan a magnitudes laborales. Se conservan pasivamente en las bases generadas pero no miden nada. |
| `upm`, `estrato`, `factor` | Variables de diseño (conglomerados/estratificación/factor de expansión). Sólo necesarias para errores muestrales complejos con bootstrapping; el estudio es descriptivo sobre la muestra. |
| `tipohogar` | Clasifica el hogar (nuclear/extendido/compuesto); no pertinente para el perfil profesional individual. |
| `area` | Urbano/rural; útil para futuros análisis de distribución espacial, pero no discrimina empleo profesional. |
| `depto` | Departamento. Se usó **sólo para clasificar** en el resumen inicial; no se incorporó al modelo de subempleo para mantener el foco nacional. |

### 7.2 Características generales y migración (`s01a_*`, `s01b_*`)
| Variable | Motivo |
|---|---|
| `s01a_04a/b/c` | Fecha de nacimiento: redundante con `s01a_03` (edad ya calculada). |
| `s01a_05`, `s01a_05a/b/c` | Etnia / autopertenencia: fuera del alcance (no se pidió análisis por etnia). |
| `s01a_06` | Lengua materna: idem. |
| `s01a_07*` | Si vive con pareja: demográfico, no laboral. |
| `s01a_08` | Lugar donde vive: redundante geográfico. |
| `s01a_09`, `s01a_10` | Relación de parentesco: estructural del hogar. |
| `s01b_*` | Migración interna/internacional: objeto de estudio distinto (movilidad). |

### 7.3 Salud (`s02a_*`–`s02d_*`)
| Variable | Motivo |
|---|---|
| `s02a_01a/b/e` | Afiliación a seguros de salud: determinante de salud, no laboral. |
| `s02a_02a–h` | Atención médica previa: idem. |
| `s02a_03–05` | Discapacidad y registro: idem. |
| `s02b_06–14` | Salud reproductiva (embarazo, parto): población y fertilidad, no mercadolaboral. |
| `s02c_15`, `s02d_16–17` | Estado de salud general: idem. |

**Justificación general**: La salud explica *por qué* alguien no trabaja, pero aquí el problema es *cómo* trabajan los titulados; incluir salud habría introducido confusión entre causa (salud) y resultado (ocupación ajena).

### 7.4 Educación (`s03a_*`, `s03b_*`, `s03c_*`)
| Variable | Motivo |
|---|---|
| `s03a_01` | Sabe leer/escribir: redundante — todos los titulados lo saben; sin poder discriminar. |
| `s03a_01a` | Grado de alfabetización: idem. |
| `s03a_02b` | Curso específico del nivel: no se necesitó la cifra del curso dentro del nivel (el grado global `s03a_02a` es suficiente). |
| `s03a_03a/b/c` | Nivel anterior de educación: usado internamente por el INE; no aporta al perfil final. |
| `s03a_05`, `s03a_05e` | Razón de no matrícula: **sería útil** para entender por qué titulados no estudian un posgrado, pero se descartó por falta de demanda del usuario (no preguntó motivos). |
| `s03a_06a/c` | Nivel/curso al que se matriculó: se usó sólo como diagnóstico en el paso 4; no entró en el análisis final. |
| `s03a_07a`, `s03a_08` | Desayuno escolar / bono Juancito Pinto: población infantil; irrelevante para titulados. |
| `s03a_09` | Tipo de establecimiento: redundante. |
| `s03b_10–12` | Asistencia a clases y razón: tras excluir matriculados, todos están fuera; sin variabilidad útil. |
| `s03c_13–17` | Uso de computadora/Internet: mediría brecha digital, no desajuste de ocupación; se descartó por alcance. |

**Observación**: `niv_ed`, `niv_ed_g`, `educ_prev` (derivadas del INE) se descartaron como filtro/clasificador por el motivo ya explicado en el paso 3 (agregación insuficiente / redundancia), aunque son variables perfectamente válidas para otros estudios.

### 7.5 Empleo (`s04a_*`–`s04f_*`)
Variables de **empleo secundario** y **detalles de la ocupación principal** — descartadas:

| Variable | Motivo |
|---|---|
| `s04a_01`–`s04a_08` | Preguntas de flujo para construir `condact` (trabajó/buscó/disponible). Redundantes: el 100% de la información ya está resumida en `condact`/`pea`. |
| `s04b_10a_cod` | Código CAEB 2022 de la ocupación: mismo contenido que `caeb_op` en formato crudo. |
| `s04b_11aa/ab`, `s04b_11ba/bb` | Antigüedad en la ocupación: útil para moverilidad pero no para el diagnóstico actual. |
| `s04b_12` | Posición en la ocupación (obrero/empleador/cuenta propia): **se usó informalmente** al interpretar, pero no formó parte del modelo; podría añadirse en un análisis futuro. |
| `s04b_13`, `s04b_14` | Tipo de administración y tamaño de establecimiento: detalle sin relación directa con la competencia profesional. |
| `s04b_15`, `s04b_16aa/ab` | Días y horas: mediría subempleo *por tiempo*, no por competencias (objeto del estudio). |
| `s04c_*` | Beneficios y protección laboral: otro enfoque (calidad del empleo); se dejó para análisis aparte. |
| `s04d_22a/b`–`s04d_24bc` | Ingresos brutos sin normalizar y producción para autoconsumo: sustituidos por `yprilab` (más limpio). |
| `s04e_25`–`s04e_30b`, `s04f_31a`–`s04f_36` | Segunda ocupación, ingresos secundarios, seguridad social, aportes AFP: se concentró en la ocupación principal para comparabilidad; el secundario erosiona la claridad sin cambiar el diagnóstico. |
| `caeb_os`, `cob_os` (derivados de secundaria) | Idem. |
| `phrs`, `shrs`, `tothrs` | Horas semanales (principal/secundaria/total): subempleo de tiempo, no de competencias. |

**Regla de oro aplicada**: *"qué hace"* se mide con el grupo ocupacional (`cob_op`); *"dónde lo hace"* con la rama (`caeb_op`); *"cuánto gana"* con el ingreso mensualizado (`yprilab`). Todo el resto de la sección de empleo es redundante con alguna de estas tres o pertenece a otra pregunta de investigación.

### 7.6 Ingresos no laborales (`s05a_*`–`s05c_*`)
| Variable | Motivo |
|---|---|
| `s05a_01a–f` | Salario + otros ingresos laborales: duplicado del ingreso laboral. |
| `s05a_02a/c/ce` | Rentas (intereses, alquileres): ingreso no laboral; fuera del análisis de mercado de trabajo. |
| `s05a_03a–c`, `s05a_04a–d` | Remesas, indemnizaciones, becas: ingreso extraordinario; no pertenece al perfil ocupacional. |
| `s05b_*`, `s05c_*` | Bonos sociales y envíos en especie: política social; no laboral. |
| `s05c_09a/b/be/aa`, `s05c_10` | Moneda y montos de remesas: idem. |

### 7.7 Variables derivadas adicionales del INE
| Variable | Motivo |
|---|---|
| `cmasi` | Coeficiente de calidad educativa agregada: no es un indicador de empleo. |
| `cobersalud` | Cobertura de salud: salud, no laboral. |
| `hnv_ult_a`, `quienatenparto` | Salud reproductiva derivada: idem. |
| `pet`, `pei` | Población en edad de trabajar / inactiva: se usaron como verificación; no como clasificador (ver 4.1). |
| `z`, `zext`, `p0`, `p1`, `p2`, `pext0–2` | Líneas de pobreza y probabilidades de pobreza: miden bienestar monetario, no desajuste educativo. |
| `yper`, `yhog`, `yhogpc` | Ingresos per cápita y totales del hogar: nivel agregado; el análisis es individual. |
| `ylab`, `ynolab` | Ingresos laboral/no laboral totaales: agregados hogar; duplican los individuales que ya usamos (`yprilab`). |

---

## 8. Limitaciones metodológicas

1. **Ausencia de variable de carrera**: el desglose por profesión se infiere de la ocupación actual vía COB 2023; no se puede deducir la carrera de los desocupados ni de los subempleados. No es un defecto del procesamiento, sino una característica de la Encuesta de Hogares (a diferencia del Censo, que tampoco la recoge para educación superior).
2. **Ponderación**: el análisis usa la muestra sin aplicar `factor` de expansión. Las cifras son **estimaciones muestrales**, no proyecciones poblacionales. Para cifras poblacionales habría que expandir con `factor` y calcular errores muestrales con `upm`/`estrato`.
3. **Subempleo definido por grupos ocupacionales**: un titulado en grupo 2–3 se asume "ejerciendo", pero podría estar en una ocupación de su grupo no afín a su carrera (p. ej. biólogo trabajando de administrador del conocimiento). El dato de carrera impediría afinar; el grado de aproximación es aceptable y estándar en este tipo de estudios.
4. **Corte de matrícula binario**: excluye de una vez a todos los matriculados 2025, incluso casos de formación continua. Decisión explícita del usuario; su efecto es conservador (puede eliminar algunos titulados que estudian un posgrado adicional).
5. **Codificación de etiquetas**: diferencias de encoding en el diccionario (sólo visuales); los valores numéricos son íntegros.
6. **Ingreso**: valores extremos se controlan con medianas; el análisis de desigualdad de ingresos no forma parte de este informe.

---

## 9. Reproducibilidad — archivos generados

| Archivo | Contenido |
|---|---|
| `procesar_personas.py` | Filtros secuenciales 1–4 (separación de datos) |
| `analisis_empleo.py` | Resúmenes por grado, profesión, ramas y oficios |
| `informe_empleo.py` | Genera informe `.md`/`.docx` |
| `EH2025_Persona_Filtrada.sav/.csv` | 21–70 años y >13 años de estudio (8,181) |
| `EH2025_Persona_Profesionales.sav/.csv` | 6,422 titulados (sin matriculados) |
| `informe_empleo_profesionales.xlsx` | Tablas de respaldo por grado/profesión/ramas/oficios |
| `INFORME_EMPLEO_PROFESIONALES_BOLIVIA.md/.docx` | Informe de resultados |
| `subempleados_rama.csv` | Detalle de los 2,548 subempleados |

---

*Elaborado a partir del procesamiento realizado con `EH2025_Persona.sav` (INE – Encuesta de Hogares 2025).*