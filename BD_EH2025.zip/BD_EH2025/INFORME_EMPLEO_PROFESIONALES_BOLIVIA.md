# DIAGNÓSTICO LABORAL DE PROFESIONALES TITULADOS EN BOLIVIA (EH 2025)

**Fuente**: INE – Encuesta de Hogares 2025 (`EH2025_Persona.sav`).

**Población objetivo**: 6,422 profesionales titulados de 21 a 70 años (>13 años de estudio, sin matrícula 2025).

**Clasificación**: categorías profesionales INE (COB 2023 – grandes grupos 2 y 3: Profesionales científicos e intelectuales y Técnicos de nivel medio), por grado académico aprobado (s03a_02a).

---

## 1. RESUMEN EJECUTIVO

| Indicador | Valor |
|---|---|
| Población profesional titulada (21–70) | 6,422 |
| Población Económicamente Activa (PEA) | 5,491 |
| Ocupados | 5,155 |
| Desocupados (cesantes + aspirantes) | 336 |
| No PEA | 931 |
| **Tasa de desempleo abierto** | **6.12%** |
| Ejercen ocupación profesional/técnica | 2,607 (50.6% de ocupados) |
| **Subempleo por competencias** (ocupados en ramas ajenas a su formación) | **2,548 (49.4% de ocupados)** |
| Ingreso mediano de quienes ejercen | Bs 4,765/mes |
| Ingreso mediano en subempleo | Bs 3,250/mes |

> El desempleo abierto (6,12%) esconde la verdadera crisis: **la mitad de los titulados ocupados trabaja en oficios ajenos a su profesión**. Sólo 1 de cada 2 profesionales ejerce en una ocupación de su nivel de formación.

---

## 2. DESGLOSE POR GRADO ACADÉMICO

| Grado | Total | PEA | Ocupados | Desocup. | TD% | Ejercen | Subempleo | Sub%Ocup |
|---|---|---|---|---|---|---|---|---|
| Técnico Medio | 516 | 426 | 407 | 19 | 4.5% | 95 | 312 | 76.7% |
| Técnico Superior | 1,125 | 960 | 915 | 45 | 4.7% | 258 | 657 | 71.8% |
| Licenciatura | 4,300 | 3,676 | 3,417 | 259 | 7.0% | 1,930 | 1,487 | 43.5% |
| Diplomado | 232 | 211 | 203 | 8 | 3.8% | 146 | 57 | 28.1% |
| Maestría | 217 | 193 | 189 | 4 | 2.1% | 158 | 31 | 16.4% |
| Doctorado | 32 | 25 | 24 | 1 | 4.0% | 20 | 4 | 16.7% |

**Lectura**: el subempleo por competencias es inverso al nivel de posgrado: 76,7% en Técnico Medio, 71,8% en Técnico Superior, 43,5% en Licenciatura, y menos de 30% en posgrados.

---

## 3. DESGLOSE POR PROFESIÓN (COB 2023 – subgrupos) Y GRADO

Sólo es posible clasificar por profesión a quienes **ejercen** una ocupación profesional o técnica (código COB en grandes grupos 2–3). El detalle por grado: 


| Profesión (subgrupo COB 2023) | Diplomado | Doctorado | Licenciatura | Maestría | Técnico Medio | Técnico Superior | Total |
|---|---|---|---|---|---|---|---|
| Profesores de enseñanza primaria e inicial | 12 | 0 | 282 | 3 | 1 | 21 | 319 |
| Profesionales en derecho | 20 | 2 | 179 | 17 | 0 | 0 | 218 |
| Profesores de enseñanza secundaria | 10 | 0 | 158 | 3 | 1 | 3 | 175 |
| Profesionales en finanzas | 9 | 0 | 143 | 6 | 0 | 2 | 160 |
| Otros profesionales de la salud | 14 | 2 | 119 | 12 | 0 | 2 | 149 |
| Profesionales de enfermería y partería | 1 | 0 | 115 | 10 | 0 | 0 | 126 |
| Médicos | 7 | 6 | 68 | 23 | 0 | 0 | 104 |
| Técnicos en ciencias físicas y en ingeniería | 1 | 0 | 35 | 0 | 13 | 44 | 93 |
| Arquitectos, urbanistas, agrimensores y diseñadores | 6 | 0 | 83 | 1 | 1 | 0 | 91 |
| Profesores de universidades y de la enseñanza superior y superior no universitaria | 11 | 5 | 35 | 31 | 0 | 4 | 86 |
| Técnicos de nivel medio de enfermería y partería | 0 | 0 | 5 | 0 | 24 | 45 | 74 |
| Agentes comerciales y corredores | 4 | 0 | 45 | 1 | 4 | 9 | 63 |
| Técnicos de nivel medio en finanzas y matemáticas | 3 | 1 | 39 | 2 | 1 | 16 | 62 |
| Desarrolladores y analistas de software y multimedia | 6 | 0 | 48 | 6 | 0 | 0 | 60 |
| Ingenieros (excluyendo electrotecnólogos) | 4 | 0 | 49 | 6 | 0 | 0 | 59 |
| Especialistas en ciencias sociales y teología | 6 | 1 | 45 | 6 | 0 | 0 | 58 |
| Profesionales en ciencias biológicas | 6 | 2 | 37 | 11 | 0 | 0 | 56 |
| Técnicos de nivel medio en actividades culturales, artísticas y culinarias | 2 | 0 | 22 | 2 | 6 | 20 | 52 |
| Supervisores en ingeniería de minas, de industrias manufactureras y de la construcción | 4 | 0 | 35 | 0 | 1 | 9 | 49 |
| Profesionales de las ventas, la comercialización y las relaciones públicas | 1 | 0 | 43 | 0 | 2 | 2 | 48 |
| Secretarios administrativos y especializados | 0 | 0 | 29 | 0 | 6 | 12 | 47 |
| Técnicos en operaciones de tecnología de la información y las comunicaciones y asistencia al usuario | 1 | 0 | 29 | 0 | 1 | 14 | 45 |
| Agentes de servicios comerciales | 2 | 0 | 38 | 1 | 1 | 3 | 45 |
| Otros profesionales de la enseñanza | 2 | 0 | 27 | 4 | 5 | 4 | 42 |
| Técnicos médicos y farmacéuticos | 0 | 0 | 14 | 0 | 10 | 10 | 34 |
| Agentes de la administración pública para la aplicación de la ley y afines | 1 | 0 | 19 | 1 | 2 | 6 | 29 |
| Especialistas en organización de administración | 2 | 0 | 22 | 4 | 0 | 0 | 28 |
| Ingenieros en electrotecnología | 1 | 0 | 23 | 3 | 0 | 0 | 27 |
| Técnicos en telecomunicaciones y radiodifusión | 1 | 0 | 17 | 0 | 4 | 4 | 26 |
| Técnicos de nivel medio, de servicios jurídicos, sociales y religiosos | 0 | 0 | 20 | 1 | 1 | 3 | 25 |

*Ingreso mediano ejerciendo: Bs 4,765/mes.*

---

## 4. RAMAS DE ACTIVIDAD DE REFUGIO (DÓNDE SE PIERDE EL TALENTO)

Distribución de los ocupados en subempleo por rama de actividad económica (CAEB 2022):


| Rama de actividad | Profesionales absorbidos | % del subempleo |
|---|---|---|
| Venta por mayor y menor,reparación de automotores | 799 | 31.4% |
| Industria Manufacturera | 310 | 12.2% |
| Transporte y Almacenamiento | 239 | 9.4% |
| Actividades de alojamiento y servicio de comidas | 194 | 7.6% |
| Adm. Pública, Defensa y Seguridad Social | 188 | 7.4% |
| Agricultura,Ganadería,Caza,Pesca y Silvicultura | 172 | 6.8% |
| Construcción | 133 | 5.2% |
| Servicios de Educación | 95 | 3.7% |
| Otras actividades de servicios | 89 | 3.5% |
| Intermediacion Financiera y Seguros | 73 | 2.9% |
| Actividades de Servicios Administrativos y de Apoyo | 64 | 2.5% |
| Servicios de Salud y Asistencia Social | 49 | 1.9% |
| Explotación de Minas y Canteras | 38 | 1.5% |
| Actividades de Hogares Privados | 25 | 1.0% |
| Servicios Profesionales y Técnicos | 19 | 0.7% |

**Total subempleados: 2,548**

---

## 5. OFICIOS DE REFUGIO (OCUPACIONES DE LOS SUBEMPLEADOS)

### 5.1 Por gran grupo ocupacional (COB 2023)


| Gran grupo ocupacional | Profesionales | % del subempleo |
|---|---|---|
| Trabajadores de Servicio y Vendedores | 993 | 39.0% |
| Trabajadores de la Construcción, Ind. Manufacturera y Otros | 525 | 20.6% |
| Empleados de oficina | 331 | 13.0% |
| Operadores de Instalaciones y Maquinarias | 272 | 10.7% |
| Trabajadores en Agricultura, Pecuaria,Pesca y otros | 158 | 6.2% |
| Directivos Adm. Pública y Empresas | 123 | 4.8% |
| Trabajadores No Calificados | 112 | 4.4% |
| Fuerzas Armadas | 34 | 1.3% |

### 5.2 Por ocupación concreta (códigos COB más frecuentes)


| Ocupación | Profesionales |
|---|---|
| Vendedores de tiendas y almacenes | 358 |
| Vendedores de quioscos y puestos de mercado | 134 |
| Conductores de automóviles, taxis y camionetas | 112 |
| Mecánicos y reparadores de vehículos de motor | 108 |
| Secretarios generales | 63 |
| Guardias de seguridad y vigilantes | 56 |
| Cocineros | 56 |
| Empleados de control de abastecimiento e inventarios | 53 |
| Modistas, sastres y afines | 49 |
| Cajeros y expendedores de boletos | 46 |
| Panaderos, pasteleros y confiteros | 43 |
| Conductores de camiones pesados | 41 |
| Vendedores por catálogo y otros | 41 |
| Otros empleados de servicios de correo y mensajería | 36 |
| Conductores de motocicletas | 34 |
| Peluqueros, barberos y estilistas | 32 |
| Dependientes de venta no clasificados | 30 |
| Auxiliares de contabilidad y cálculo | 30 |
| Limpiadores y asistentes domésticos | 29 |
| Asistentes docentes y paraeducadores | 28 |

---

## 6. CONCLUSIONES

1. **Desempleo bajo, subempleo masivo**: la tasa de desempleo abierto alcanza sólo 6.12%, pero el 49.4% de los profesionales ocupados trabaja en ocupaciones de menor calificación (comercio, choferes, construcción, servicios).
2. **El posgrado protege**: mientras 7 de cada 10 técnicos (nivel medio/superior) están subempleados, menos de 3 de cada 10 con maestría o doctorado lo están.
3. **Rutas de precarización**: comercio (799 profesionales), industria manufacturera (310) y transporte (239) son los principales 'vertedores' de talento profesional.
4. **Penalización salarial**: el ingreso mediano cae de Bs 4,765 a Bs 3,250 cuando el profesional deja de ejercer su carrera (-31.8%).
5. **Para el PAD/PTDI municipal**: fomentar carreras técnicas con demanda local comprobada y crear oficinas de enlace laboral para recolocar a los profesionales desplazados.