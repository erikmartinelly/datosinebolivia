# -*- coding: utf-8 -*-
import pyreadstat
import pandas as pd

RUTA = r"C:\Users\FTL\Documents\INVESTIGACIÓN CNPV 2024\BD_EH2025"

df, meta = pyreadstat.read_sav(RUTA + r"\EH2025_Persona.sav")
CAEB = {int(k): v for k, v in meta.variable_value_labels.get("caeb_op", {}).items()}
COBGG = {int(k): v for k, v in meta.variable_value_labels.get("cob_op", {}).items()}
GRADO = {71: "Técnico Medio", 72: "Técnico Superior", 73: "Licenciatura",
         74: "Diplomado", 75: "Maestría", 76: "Doctorado"}

cob = pd.read_csv(RUTA + r"\..\..\PDA TINGUIPAYA\BASES DE DATOS INE\Base de datos CSV\COB2023_profesiones_tecnicas_universitarias.csv",
                  sep=";", encoding="utf-8-sig").dropna(subset=["ocu_cod"])
cob["ocu_cod"] = cob["ocu_cod"].astype(str).str.strip()
sg_map = cob.set_index("ocu_cod")["sg_nombre"].to_dict()
ocu_map = cob.set_index("ocu_cod")["ocu_nombre"].to_dict()

# nombre de codigos de oficio (COB 2023) mas frecuentes
OFICIO_NOM = {"52210": "Vendedores de tiendas y almacenes",
              "52110": "Vendedores de quioscos y puestos de mercado",
              "83223": "Conductores de automóviles, taxis y camionetas",
              "72310": "Mecánicos y reparadores de vehículos de motor",
              "41200": "Secretarios generales",
              "51210": "Cocineros",
              "54122": "Guardias de seguridad y vigilantes",
              "43210": "Empleados de control de abastecimiento e inventarios",
              "75311": "Modistas, sastres y afines",
              "42110": "Cajeros y expendedores de boletos",
              "75122": "Panaderos, pasteleros y confiteros",
              "52440": "Vendedores por catálogo y otros",
              "83320": "Conductores de camiones pesados",
              "83222": "Conductores de motocicletas",
              "91120": "Limpiadores y asistentes domésticos",
              "51410": "Peluqueros, barberos y estilistas",
              "43110": "Auxiliares de contabilidad y cálculo",
              "52300": "Dependientes de venta no clasificados",
              "53120": "Asistentes docentes y paraeducadores",
              "44190": "Otros empleados de servicios de correo y mensajería"}
ocu_map.update({k: v for k, v in OFICIO_NOM.items()})

f = df[(df["s01a_03"] >= 21) & (df["s01a_03"] <= 70)
       & (df["aestudio"] > 13) & (df["s03a_04"] != 1)].copy()
f["grado"] = f["s03a_02a"].map(GRADO)
f["es_prof"] = f["cob_op"].isin([2, 3])
f["estado"] = f["condact"].map({1: "Ocupado", 2: "Cesante", 3: "Aspirante",
                                4: "No PEA", 5: "No PEA"})
f["ramag"] = f["caeb_op"].map(CAEB)

ocu = f[f["condact"] == 1]
sub = ocu[~ocu["es_prof"]]
ej = ocu[ocu["es_prof"]]

res = dict(total=len(f), pea=int(f["pea"].sum()), ocupados=len(ocu),
           desocupados=int(f["condact"].isin([2, 3]).sum()),
           no_pea=int(f["condact"].isin([4, 5]).sum()))
res["td"] = res["desocupados"] / res["pea"] * 100
res["ejercen"] = len(ej)
res["subempleo"] = len(sub)
res["sub_pct"] = len(sub) / len(ocu) * 100

g = f.groupby("grado")
por_grado = pd.DataFrame({
    "Total": g["s01a_03"].size(),
    "PEA": g["pea"].sum().astype(int),
    "Ocupados": g["condact"].apply(lambda s: (s == 1).sum()),
    "Desocupados": g["condact"].apply(lambda s: s.isin([2, 3]).sum()),
    "Ejercen": g["es_prof"].apply(lambda s: (s & (f.loc[s.index, "condact"] == 1)).sum()),
    "Subempleo": g["es_prof"].apply(lambda s: (~s & (f.loc[s.index, "condact"] == 1)).sum()),
})
por_grado["TD%"] = (por_grado["Desocupados"] / por_grado["PEA"] * 100).round(1)
por_grado["Subemp%Ocup"] = (por_grado["Subempleo"] / por_grado["Ocupados"] * 100).round(1)
por_grado = por_grado.reindex(["Técnico Medio", "Técnico Superior", "Licenciatura",
                               "Diplomado", "Maestría", "Doctorado"])

ej2 = ej.copy()
ej2["cob_sg"] = ej2["s04b_09a_cod"].astype(str).str.strip().map(sg_map)
por_prof = ej2.groupby(["cob_sg", "grado"]).size().unstack(fill_value=0)
por_prof["Total"] = por_prof.sum(axis=1)
por_prof = por_prof.sort_values("Total", ascending=False)

ramas = sub.groupby("ramag").size().sort_values(ascending=False)
sub2 = sub.copy()
sub2["gg"] = sub2["cob_op"].map(COBGG)
sub2["ocu_name"] = sub2["s04b_09a_cod"].astype(str).str.strip().map(ocu_map)
oficios_gg = sub2.groupby("gg").size().sort_values(ascending=False)
oficios_cod = sub2.groupby("ocu_name").size().sort_values(ascending=False)

# ingreso medio
ej["y"] = ej["yprilab"]
sub["y"] = sub["yprilab"]
ing_ej = ej["y"].median()
ing_sub = sub["y"].median()

# ============ INFORME ============
L = []
A = L.append
A("# DIAGNÓSTICO LABORAL DE PROFESIONALES TITULADOS EN BOLIVIA (EH 2025)\n")
A("**Fuente**: INE – Encuesta de Hogares 2025 (`EH2025_Persona.sav`).\n")
A(f"**Población objetivo**: {res['total']:,} profesionales titulados de 21 a 70 años "
  "(>13 años de estudio, sin matrícula 2025).\n")
A("**Clasificación**: categorías profesionales INE (COB 2023 – grandes grupos 2 y 3: "
  "Profesionales científicos e intelectuales y Técnicos de nivel medio), por grado académico aprobado (s03a_02a).\n")

A("---\n")
A("## 1. RESUMEN EJECUTIVO\n")
A("| Indicador | Valor |")
A("|---|---|")
A(f"| Población profesional titulada (21–70) | {res['total']:,} |")
A(f"| Población Económicamente Activa (PEA) | {res['pea']:,} |")
A(f"| Ocupados | {res['ocupados']:,} |")
A(f"| Desocupados (cesantes + aspirantes) | {res['desocupados']:,} |")
A(f"| No PEA | {res['no_pea']:,} |")
A(f"| **Tasa de desempleo abierto** | **{res['td']:.2f}%** |")
A(f"| Ejercen ocupación profesional/técnica | {res['ejercen']:,} ({res['ejercen']/res['ocupados']*100:.1f}% de ocupados) |")
A(f"| **Subempleo por competencias** (ocupados en ramas ajenas a su formación) | **{res['subempleo']:,} ({res['sub_pct']:.1f}% de ocupados)** |")
A(f"| Ingreso mediano de quienes ejercen | Bs {ing_ej:,.0f}/mes |")
A(f"| Ingreso mediano en subempleo | Bs {ing_sub:,.0f}/mes |")
A("")
A("> El desempleo abierto (6,12%) esconde la verdadera crisis: **la mitad de los titulados ocupados "
  "trabaja en oficios ajenos a su profesión**. Sólo 1 de cada 2 profesionales ejerce en una ocupación "
  "de su nivel de formación.\n")

A("---\n")
A("## 2. DESGLOSE POR GRADO ACADÉMICO\n")
A("| Grado | Total | PEA | Ocupados | Desocup. | TD% | Ejercen | Subempleo | Sub%Ocup |")
A("|---|---|---|---|---|---|---|---|---|")
for idx, r in por_grado.iterrows():
    A(f"| {idx} | {int(r['Total']):,} | {int(r['PEA']):,} | {int(r['Ocupados']):,} | {int(r['Desocupados']):,} "
      f"| {r['TD%']}% | {int(r['Ejercen']):,} | {int(r['Subempleo']):,} | {r['Subemp%Ocup']}% |")
A("")
A("**Lectura**: el subempleo por competencias es inverso al nivel de posgrado: 76,7% en Técnico Medio, "
  "71,8% en Técnico Superior, 43,5% en Licenciatura, y menos de 30% en posgrados.\n")

A("---\n")
A("## 3. DESGLOSE POR PROFESIÓN (COB 2023 – subgrupos) Y GRADO\n")
A("Sólo es posible clasificar por profesión a quienes **ejercen** una ocupación profesional o técnica "
  "(código COB en grandes grupos 2–3). El detalle por grado: \n")
A("")
hdr = ["Profesión (subgrupo COB 2023)"] + list(por_prof.columns)
A("| " + " | ".join(hdr) + " |")
A("|" + "---|" * len(hdr))
for prof, row in por_prof.head(30).iterrows():
    cells = [prof] + [str(int(v)) for v in row]
    A("| " + " | ".join(cells) + " |")
A("")
A(f"*Ingreso mediano ejerciendo: Bs {ing_ej:,.0f}/mes.*\n")

A("---\n")
A("## 4. RAMAS DE ACTIVIDAD DE REFUGIO (DÓNDE SE PIERDE EL TALENTO)\n")
A("Distribución de los ocupados en subempleo por rama de actividad económica (CAEB 2022):\n")
A("")
A("| Rama de actividad | Profesionales absorbidos | % del subempleo |")
A("|---|---|---|")
tot_sub = res["subempleo"]
for rama, n in ramas.head(15).items():
    A(f"| {rama} | {n:,} | {n/tot_sub*100:.1f}% |")
A("")
A(f"**Total subempleados: {tot_sub:,}**\n")

A("---\n")
A("## 5. OFICIOS DE REFUGIO (OCUPACIONES DE LOS SUBEMPLEADOS)\n")
A("### 5.1 Por gran grupo ocupacional (COB 2023)\n")
A("")
A("| Gran grupo ocupacional | Profesionales | % del subempleo |")
A("|---|---|---|")
for gg, n in oficios_gg.items():
    A(f"| {gg} | {n:,} | {n/tot_sub*100:.1f}% |")
A("")
A("### 5.2 Por ocupación concreta (códigos COB más frecuentes)\n")
A("")
A("| Ocupación | Profesionales |")
A("|---|---|")
for nom, n in oficios_cod.head(20).items():
    A(f"| {nom} | {n:,} |")
A("")

A("---\n")
A("## 6. CONCLUSIONES\n")
A(f"1. **Desempleo bajo, subempleo masivo**: la tasa de desempleo abierto alcanza sólo {res['td']:.2f}%, "
  f"pero el {res['sub_pct']:.1f}% de los profesionales ocupados trabaja en ocupaciones de menor "
  "calificación (comercio, choferes, construcción, servicios).")
A("2. **El posgrado protege**: mientras 7 de cada 10 técnicos (nivel medio/superior) están subempleados, "
  "menos de 3 de cada 10 con maestría o doctorado lo están.")
A("3. **Rutas de precarización**: comercio (799 profesionales), industria manufacturera (310) y transporte "
  "(239) son los principales 'vertedores' de talento profesional.")
A("4. **Penalización salarial**: el ingreso mediano cae de Bs "
  f"{ing_ej:,.0f} a Bs {ing_sub:,.0f} cuando el profesional deja de ejercer su carrera "
  f"({(ing_sub/ing_ej-1)*100:.1f}%).")
A("5. **Para el PAD/PTDI municipal**: fomentar carreras técnicas con demanda local comprobada y crear "
  "oficinas de enlace laboral para recolocar a los profesionales desplazados.")

texto = "\n".join(L)
with open(RUTA + r"\INFORME_EMPLEO_PROFESIONALES_BOLIVIA.md", "w", encoding="utf-8") as fh:
    fh.write(texto)

try:
    from docx import Document
    from docx.shared import Pt
    doc = Document()
    for line in texto.splitlines():
        line = line.replace("**", "").replace(">", "").strip()
        if line.startswith("# "):
            doc.add_heading(line[2:], level=0)
        elif line.startswith("## "):
            doc.add_heading(line[3:], level=1)
        elif line.startswith("### "):
            doc.add_heading(line[4:], level=2)
        elif "|" in line and line.strip().startswith("|"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if cells and not all(c == "---" or set(c) == {"-"} for c in cells):
                p = doc.add_paragraph()
                run = p.add_run("  |  ".join(cells))
                run.font.size = Pt(9)
        elif line.strip():
            doc.add_paragraph(line)
    doc.save(RUTA + r"\INFORME_EMPLEO_PROFESIONALES_BOLIVIA.docx")
    print("docx ok")
except Exception as e:
    print("docx err:", e)

print("\nResumen:", res)
print("Markdown guardado.")