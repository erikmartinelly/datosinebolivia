# -*- coding: utf-8 -*-
import pyreadstat
import pandas as pd

RUTA = r"C:\Users\FTL\Documents\INVESTIGACIÓN CNPV 2024\BD_EH2025"
SAV = RUTA + r"\EH2025_Persona.sav"
SALIDA = RUTA + r"\EH2025_Persona_Filtrada.sav"
CSV = RUTA + r"\EH2025_Persona_Filtrada.csv"
SALIDA_PRO = RUTA + r"\EH2025_Persona_Profesionales.sav"
CSV_PRO = RUTA + r"\EH2025_Persona_Profesionales.csv"

EDAD = "s01a_03"
EDUC = "aestudio"

df, meta = pyreadstat.read_sav(SAV)
total = len(df)

print("=" * 60)
print("Archivo:", SAV)
print(f"Total de registros originales: {total}")

# Paso 1: eliminar menores de 21 años
df1 = df[df[EDAD] >= 21].copy()
print(f"\n[1] Menores de 21 años eliminados: {total - len(df1)}")
print(f"    Registros restantes: {len(df1)}")

# Paso 2: eliminar mayores de 70 años
df2 = df1[df1[EDAD] <= 70].copy()
print(f"[2] Mayores de 70 años eliminados: {len(df1) - len(df2)}")
print(f"    Registros restantes: {len(df2)}")

# Paso 3: eliminar personas con 13 años de educación o menos
df3 = df2[df2[EDUC] > 13].copy()
print(f"[3] Con 13 años de educación o menos eliminados: {len(df2) - len(df3)}")
print(f"    Registros restantes: {len(df3)}")

print("=" * 60)
print(f"\nPoblación final (21-70 años y >13 años de estudio): {len(df3)}")

# Paso 4: quitar a los actualmente matriculados (grado en curso / inconcluso)
df4 = df3[df3["s03a_04"] != 1].copy()
print(f"[4] Actualmente matriculados 2025 (grado inconcluso) eliminados: {len(df3) - len(df4)}")
print(f"    Registros restantes: {len(df4)}")

print("=" * 60)
print(f"\nPoblación profesional final (titulados no matriculados): {len(df4)}")

# Clasificación final
g = df3.groupby("depto").size().sort_values(ascending=False)
print("\nClasificación por departamento:")
for d, c in g.items():
    print(f"  Depto {int(d)}: {c}")

print("\nAños de estudio (distribución):")
print(df4[EDUC].value_counts().sort_index())

print("\nNivel profesional aprobado (s03a_02a):")
print(df4["s03a_02a"].value_counts().sort_index())

print("\nSexo (s01a_02):")
print(df4["s01a_02"].value_counts())

# Guardar resultados
pyreadstat.write_sav(df3, SALIDA, variable_value_labels=meta.variable_value_labels, column_labels=meta.column_names_to_labels)
df3.to_csv(CSV, index=False, encoding="utf-8-sig")
pyreadstat.write_sav(df4, SALIDA_PRO, variable_value_labels=meta.variable_value_labels, column_labels=meta.column_names_to_labels)
df4.to_csv(CSV_PRO, index=False, encoding="utf-8-sig")
print(f"\nGuardado en:\n  {SALIDA}\n  {CSV}\n  {SALIDA_PRO}\n  {CSV_PRO}")