# -*- coding: utf-8 -*-
"""
================================================================================
SCRIPT PARA GOOGLE COLAB: TRATAMIENTO LONGITUDINAL DE LAS BASES DE DATOS EH
Años: 2006, 2016 y 2025 (INE Bolivia - Proyecciones CNPV 2024)
================================================================================
Instrucciones en Google Colab:
1. Copia y pega las secciones en celdas de Colab o ejecuta el script completo.
2. Si subes los archivos directamente a Colab, déjalos en la carpeta raíz (/content/).
3. Si los tienes en Google Drive, activa la opción de montar Drive indicada abajo.
================================================================================
"""

# CELDA 1: Instalación de librerías necesarias
# ------------------------------------------------------------------------------
# Descomenta en Google Colab:
# !pip install pyreadstat openpyxl seaborn matplotlib pandas numpy

import os
import sys
import pyreadstat
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Configuración visual para gráficos en Colab
sns.set_theme(style="whitegrid", palette="muted")
plt.rcParams.update({
    'font.sans-serif': 'DejaVu Sans',
    'font.family': 'sans-serif',
    'figure.titlesize': 13,
    'axes.titlesize': 11,
    'axes.labelsize': 10,
    'figure.dpi': 150
})

print(">> Librerías importadas correctamente.")

# CELDA 2: Montaje de Google Drive o Definición de Rutas
# ------------------------------------------------------------------------------
# Si ejecutas en Google Colab con Google Drive montado:
# from google.colab import drive
# drive.mount('/content/drive')
# RUTA_BASE = '/content/drive/MyDrive/INVESTIGACION_CNPV_2024/'

# Rutas flexibles: Detecta si está en Google Colab o en ejecución local
EN_COLAB = 'google.colab' in sys.modules

if EN_COLAB:
    print(">> Entorno detectado: GOOGLE COLAB")
    # Si subes los archivos a /content/ en Colab:
    RUTA_06 = "/content/EH2006_Poblacion.sav"
    RUTA_16 = "/content/EH2016_Personas.sav"
    RUTA_25 = "/content/EH2025_Persona.sav"
    DIR_SALIDA = "/content/salidas_analisis/"
else:
    print(">> Entorno detectado: LOCAL")
    RUTA_06 = r"C:\Users\FTL\Downloads\bd25\BASE EH 2006\EH2006_Poblacion.sav"
    RUTA_16 = r"C:\Users\FTL\Downloads\BD_EH-2016\BD_EH2016\EH2016_Personas.sav"
    RUTA_25 = r"C:\Users\FTL\Documents\INVESTIGACIÓN CNPV 2024\BD_EH2025\EH2025_Persona.sav"
    DIR_SALIDA = r"C:\Users\FTL\Documents\INVESTIGACIÓN CNPV 2024\BD_EH2025\salidas_colab\\"

os.makedirs(DIR_SALIDA, exist_ok=True)


# CELDA 3: Función de Tratamiento y Armonización Metodológica
# ------------------------------------------------------------------------------
def procesar_eh2006(ruta):
    print(">> Procesando EH 2006...")
    df, meta = pyreadstat.read_sav(ruta)
    
    # 1. Filtro Edad (21 a 70 años)
    f_edad = (df['s1_03'] >= 21) & (df['s1_03'] <= 70)
    
    # 2. Filtro Nivel Educativo (Universitario / Normal / Técnico)
    # 24:Normal, 25:Univ pub, 26:Univ priv, 27:Postgrado, 28:Tec Univ, 29:Tec Inst, 30:Militar
    f_edu = df['s4_02a'].isin([24.0, 25.0, 26.0, 27.0, 28.0, 29.0, 30.0])
    
    # 3. Excluir estudiantes activos (s4_08 == 1: asiste a clases)
    f_no_est = (df['s4_08'] != 1.0)
    
    # 4. Excluir jubilados (s6_01a > 0 o inactivo permanente condact == 5)
    f_no_jub = (df['s6_01a'].isna() | (df['s6_01a'] == 0)) & (df['condact'] != 5.0)
    
    # 5. Pertenecer a la PEA (1=Ocupados, 2=Cesantes, 3=Aspirantes)
    f_pea = df['condact'].isin([1.0, 2.0, 3.0])
    
    res = df[f_edad & f_edu & f_no_est & f_no_jub & f_pea].copy()
    
    # Clasificación laboral
    res['year'] = 2006
    res['es_ocupado'] = res['condact'] == 1.0
    res['es_desempleado'] = res['condact'].isin([2.0, 3.0])
    # Ejercen: Ocupados en cob_op 2 o 3 (Profesionales o Técnicos)
    res['es_prof'] = res['cob_op'].isin([2.0, 3.0])
    res['subempleo'] = res['es_ocupado'] & (~res['es_prof'])
    res['sexo'] = res['s1_02'].map({1.0: 'Hombre', 2.0: 'Mujer'})
    res['ingreso'] = res['ylabf']
    res['horas_semana'] = res['s5_27b'] * 5  # Estimación semanal
    
    res['grado'] = res['s4_02a'].map({
        24.0: 'Normalista', 25.0: 'Licenciatura', 26.0: 'Licenciatura',
        27.0: 'Posgrado', 28.0: 'Técnico Superior', 29.0: 'Técnico Superior', 30.0: 'Militar/Policial'
    })
    return res

def procesar_eh2016(ruta):
    print(">> Procesando EH 2016...")
    df, meta = pyreadstat.read_sav(ruta)
    
    # 1. Filtro Edad (21 a 70)
    f_edad = (df['s02a_03'] >= 21) & (df['s02a_03'] <= 70)
    
    # 2. Filtro Nivel Educativo
    # 71:Normal, 72:Univ, 73-75:Postgrados, 76:Tec Univ, 77:Tec Inst, 78:Militar
    f_edu = df['s05a_02a'].isin([71.0, 72.0, 73.0, 74.0, 75.0, 76.0, 77.0, 78.0])
    
    # 3. Excluir estudiantes activos (s05b_10 == 1: asiste a clases)
    f_no_est = (df['s05b_10'] != 1.0)
    
    # 4. Excluir jubilados (s07a_01a > 0 o condact == 5)
    f_no_jub = (df['s07a_01a'].isna() | (df['s07a_01a'] == 0)) & (df['condact'] != 5.0)
    
    # 5. PEA
    f_pea = df['condact'].isin([1.0, 2.0, 3.0])
    
    res = df[f_edad & f_edu & f_no_est & f_no_jub & f_pea].copy()
    
    res['year'] = 2016
    res['es_ocupado'] = res['condact'] == 1.0
    res['es_desempleado'] = res['condact'].isin([2.0, 3.0])
    res['es_prof'] = res['cob_op'].isin([2.0, 3.0])
    res['subempleo'] = res['es_ocupado'] & (~res['es_prof'])
    res['sexo'] = res['s02a_02'].map({1.0: 'Hombre', 2.0: 'Mujer'})
    res['ingreso'] = res['yprilab']
    res['horas_semana'] = res['phrs']
    
    res['grado'] = res['s05a_02a'].map({
        71.0: 'Normalista', 72.0: 'Licenciatura', 73.0: 'Posgrado',
        74.0: 'Posgrado', 75.0: 'Posgrado', 76.0: 'Técnico Superior', 77.0: 'Técnico Superior', 78.0: 'Militar/Policial'
    })
    return res

def procesar_eh2025(ruta):
    print(">> Procesando EH 2025...")
    df, meta = pyreadstat.read_sav(ruta)
    
    # 1. Filtro Edad (21 a 70)
    f_edad = (df['s01a_03'] >= 21) & (df['s01a_03'] <= 70)
    
    # 2. Filtro Años de estudio > 13 y Nivel
    # 71:Tec Medio, 72:Tec Superior, 73:Licenciatura, 74:Diplomado, 75:Maestria, 76:Doctorado
    f_edu = (df['aestudio'] > 13) & df['s03a_02a'].isin([71.0, 72.0, 73.0, 74.0, 75.0, 76.0])
    
    # 3. Excluir matriculados activos este año (s03a_04 == 1)
    f_no_est = (df['s03a_04'] != 1.0)
    
    # 4. Excluir inactivos permanentes / jubilados
    f_no_jub = (df['condact'] != 5.0)
    
    # 5. PEA
    f_pea = df['condact'].isin([1.0, 2.0, 3.0])
    
    res = df[f_edad & f_edu & f_no_est & f_no_jub & f_pea].copy()
    
    res['year'] = 2025
    res['es_ocupado'] = res['condact'] == 1.0
    res['es_desempleado'] = res['condact'].isin([2.0, 3.0])
    res['es_prof'] = res['cob_op'].isin([2.0, 3.0])
    res['subempleo'] = res['es_ocupado'] & (~res['es_prof'])
    res['sexo'] = res['s01a_02'].map({1.0: 'Hombre', 2.0: 'Mujer'})
    res['ingreso'] = res['yprilab']
    res['horas_semana'] = res['s04b_15a'] if 's04b_15a' in res.columns else np.nan
    
    res['grado'] = res['s03a_02a'].map({
        71.0: 'Técnico Medio', 72.0: 'Técnico Superior', 73.0: 'Licenciatura',
        74.0: 'Posgrado', 75.0: 'Posgrado', 76.0: 'Posgrado'
    })
    return res


# CELDA 4: Ejecución y Cálculo de Indicadores Clave
# ------------------------------------------------------------------------------
df06 = procesar_eh2006(RUTA_06)
df16 = procesar_eh2016(RUTA_16)
df25 = procesar_eh2025(RUTA_25)

def calcular_metricas(df_p, anio):
    total_w = df_p['factor'].sum()
    ocu_w = df_p.loc[df_p['es_ocupado'], 'factor'].sum()
    des_w = df_p.loc[df_p['es_desempleado'], 'factor'].sum()
    sub_w = df_p.loc[df_p['subempleo'], 'factor'].sum()
    ej_w = df_p.loc[df_p['es_ocupado'] & df_p['es_prof'], 'factor'].sum()
    
    td = (des_w / total_w) * 100
    sub_pct = (sub_w / ocu_w) * 100
    ej_pct = (ej_w / ocu_w) * 100
    
    y_ej = df_p.loc[df_p['es_ocupado'] & df_p['es_prof'], 'ingreso'].median()
    y_sub = df_p.loc[df_p['es_ocupado'] & (~df_p['es_prof']), 'ingreso'].median()
    brecha = ((y_sub - y_ej) / y_ej) * 100
    
    return {
        'Año': anio,
        'Muestra': len(df_p),
        'PEA_Poblacional': round(total_w),
        'Ocupados_Poblacional': round(ocu_w),
        'Desocupados_Poblacional': round(des_w),
        'Tasa_Desempleo_Pct': round(td, 2),
        'Subempleo_Competencias_Pct': round(sub_pct, 2),
        'Ejercen_Profesion_Pct': round(ej_pct, 2),
        'Mediana_Ingreso_Ejercen': round(y_ej),
        'Mediana_Ingreso_Subempleo': round(y_sub),
        'Penalizacion_Salarial_Pct': round(brecha, 2)
    }

resumen_longitudinal = pd.DataFrame([
    calcular_metricas(df06, 2006),
    calcular_metricas(df16, 2016),
    calcular_metricas(df25, 2025)
])

print("\n" + "="*80)
print("MATRIZ LONGITUDINAL COMPARATIVA (2006, 2016, 2025):")
print("="*80)
print(resumen_longitudinal.to_string(index=False))

# Guardar matriz
resumen_longitudinal.to_csv(os.path.join(DIR_SALIDA, "matriz_longitudinal_2006_2016_2025.csv"), index=False)


# CELDA 5: Generación de Gráficos Analíticos de la Serie
# ------------------------------------------------------------------------------
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

# Gráfico A: Evolución de Tasas
anios = ['2006', '2016', '2025']
sub_vals = resumen_longitudinal['Subempleo_Competencias_Pct']
td_vals = resumen_longitudinal['Tasa_Desempleo_Pct']

x = np.arange(len(anios))
w = 0.35
b1 = ax1.bar(x - w/2, sub_vals, w, label='Subempleo por Competencias (% Ocupados)', color='#d9534f', edgecolor='black')
b2 = ax1.bar(x + w/2, td_vals, w, label='Desempleo Abierto (% PEA)', color='#428bca', edgecolor='black')

ax1.set_title('Evolución del Subempleo vs Desempleo Profesional', fontsize=12, fontweight='bold')
ax1.set_xticks(x)
ax1.set_xticklabels(anios)
ax1.set_ylabel('Porcentaje (%)')
ax1.set_ylim(0, 65)
ax1.legend(loc='upper left')

for b in b1:
    h = b.get_height()
    ax1.annotate(f'{h:.1f}%', xy=(b.get_x() + b.get_width()/2, h), xytext=(0, 3), textcoords="offset points", ha='center', fontweight='bold', color='#8c1c18')
for b in b2:
    h = b.get_height()
    ax1.annotate(f'{h:.1f}%', xy=(b.get_x() + b.get_width()/2, h), xytext=(0, 3), textcoords="offset points", ha='center', fontweight='bold', color='#1d4a7a')

# Gráfico B: Brecha Salarial
y_ej_vals = resumen_longitudinal['Mediana_Ingreso_Ejercen']
y_sub_vals = resumen_longitudinal['Mediana_Ingreso_Subempleo']

b3 = ax2.bar(x - w/2, y_ej_vals, w, label='Ejercen Profesión', color='#1f77b4', edgecolor='black')
b4 = ax2.bar(x + w/2, y_sub_vals, w, label='En Subempleo', color='#ff7f0e', edgecolor='black')

ax2.set_title('Penalización Salarial por Subempleo (Bs/Mes)', fontsize=12, fontweight='bold')
ax2.set_xticks(x)
ax2.set_xticklabels(anios)
ax2.set_ylabel('Ingreso Mediano (Bs)')
ax2.set_ylim(0, 6000)
ax2.legend(loc='upper left')

for b in b3:
    h = b.get_height()
    ax2.annotate(f'Bs {h:,.0f}', xy=(b.get_x() + b.get_width()/2, h), xytext=(0, 3), textcoords="offset points", ha='center', fontweight='bold')
for b in b4:
    h = b.get_height()
    ax2.annotate(f'Bs {h:,.0f}', xy=(b.get_x() + b.get_width()/2, h), xytext=(0, 3), textcoords="offset points", ha='center', fontweight='bold')

plt.tight_layout()
ruta_fig = os.path.join(DIR_SALIDA, "grafico_colab_evolucion_y_salarios.png")
plt.savefig(ruta_fig, dpi=300)
print(f">> Gráfico analítico guardado en: {ruta_fig}")
plt.show()

print("\n>> Proceso completado exitosamente en Google Colab.")
