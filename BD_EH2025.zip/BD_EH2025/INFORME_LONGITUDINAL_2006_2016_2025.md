# ESTUDIO LONGITUDINAL: EVOLUCIÓN DEL MERCADO LABORAL CALIFICADO EN BOLIVIA (2006 - 2016 - 2025)

**Bases de datos utilizadas:**
* **2006:** INE – Encuesta de Hogares (`EH2006_Poblacion.sav`)
* **2016:** INE – Encuesta de Hogares (`EH2016_Personas.sav`)
* **2025:** INE – Encuesta de Hogares reajustada con Proyecciones CNPV 2024 (`EH2025_Persona.sav`)

**Población bajo análisis:** Personas de 21 a 70 años con formación técnica superior/media o universitaria (>13 años de estudio), sin matrícula escolar/académica activa en el año de la encuesta, pertenecientes a la Población Económicamente Activa (PEA).

---

## 1. RESUMEN EJECUTIVO: DOS DÉCADAS DE TRANSFORMACIÓN LABORAL

Al integrar los datos de 2006, 2016 y la reciente base de 2025 (post-Censo 2024), se evidencia una trayectoria de 20 años que describe el mercado profesional boliviano:

1. **La explosión demográfica de graduados:**  
   En dos décadas, la PEA con título técnico o universitario se multiplicó por **2.3 veces**, pasando de **650.435 profesionales en 2006** a **1.018.075 en 2016** y alcanzando **1.513.412 en 2025** (+132.7% de incremento total).
2. **El desempleo abierto no es la variable crítica:**  
   La tasa de desempleo abierto se ha mantenido en niveles moderados y estables: **6.73% en 2006**, **4.92% en 2016** y **5.79% en 2025** (6.12% en muestra). Bolivia no tiene un problema masivo de profesionales desocupados sin hacer nada; tiene un problema masivo de **profesionales ocupados en labores precarias**.
3. **Consolidación del Subempleo por Competencias (Sobreeducación):**  
   El porcentaje de titulados que labora en oficios ajenos a su nivel (comercio, choferes, talleres, administrativos auxiliares) creció drásticamente del **37.88% en 2006** al **50.68% en 2016**, estabilizándose en **50.12% en 2025** (49.43% en muestra). **Hoy, 1 de cada 2 profesionales o técnicos ocupados en Bolivia no ejerce su profesión.**
4. **Penalización Salarial y Pérdida de Ingresos:**  
   El castigo económico por no ejercer es severo y persistente: en 2025, un profesional que ejerce su carrera percibe una mediana de **Bs 4.765/mes**, mientras que el profesional subempleado en oficios de refugio percibe una mediana de **Bs 3.250/mes** (una brecha salarial del **-31.8%**).
5. **Estancamiento del Salario Real Profesional:**  
   Entre 2016 y 2025, la mediana salarial del profesional que ejerce solo pasó de **Bs 4.112 a Bs 4.765 (+15.9% nominal en 9 años)**, lo que indica un deterioro real frente a la inflación acumulada.

---

## 2. MATRIZ LONGITUDINAL COMPARATIVA (2006, 2016, 2025)

| Indicador Macroeconómico Laboral | Año 2006 | Año 2016 | Año 2025 (CNPV) | Tendencia 20 Años |
| :--- | :---: | :---: | :---: | :---: |
| **Muestra de profesionales en la PEA** | 1.182 | 3.714 | 5.491 | Muestra cuadruplicada |
| **PEA Profesional Ponderada (Factor)** | **650.435** | **1.018.075** | **1.513.412** | **+132.7% (Expansión masiva)** |
| **Población Ocupada Ponderada** | 606.637 | 967.971 | 1.425.759 | +135.0% |
| **Tasa de Desempleo Abierto (Ponderada)** | **6.73%** | **4.92%** | **5.79%** | Rango estable (5% - 7%) |
| *Tasa de Desempleo (Muestra directa)* | *7.02%* | *5.14%* | *6.12%* | |
| **Subempleo por Competencias (% Ocupados)** | **37.88%** | **50.68%** | **50.12%** | **Salto estructural (+12.2 p.p.)** |
| *Subempleo por Competencias (Muestra)* | *38.85%* | *50.89%* | *49.43%* | Se consolida en 50% |
| **Titulados que ejercen su nivel profesional** | **62.12%** | **49.32%** | **49.88%** | Caída por debajo de la mitad |
| **Mediana Salarial: Ejerciendo** | **Bs 1.845** | **Bs 4.112** | **Bs 4.765** | Estancamiento 2016-2025 |
| **Mediana Salarial: En Subempleo** | **Bs 1.300** | **Bs 3.031** | **Bs 3.250** | Brecha crónica |
| **Brecha Salarial por Subempleo** | **-29.5%** | **-26.3%** | **-31.8%** | Penalización creciente |

![Serie Histórica 2006-2025](grafico_serie_historica_2006_2016_2025.png)

---

## 3. LA PENALIZACIÓN SALARIAL DEL SUBEMPLEO EN EL TIEMPO

El subempleo no solo representa una pérdida de capital humano para el país, sino una pérdida económica directa para el profesional y su familia:

![Brecha Salarial](grafico_brecha_salarial_subempleo.png)

* **En 2006:** Un titulado subempleado ganaba Bs 545 menos al mes (-29.5%) que quien lograba ejercer.
* **En 2016:** La diferencia absoluta subió a Bs 1.081 menos al mes (-26.3%).
* **En 2025:** La penalización alcanza su máximo histórico: **Bs 1.515 menos al mes (-31.8%)**. Un profesional en subempleo percibe apenas Bs 3.250 mensuales (muy cercano al salario mínimo nacional y por debajo de la canasta familiar ampliada), anulando el retorno de la inversión universitaria.

---

## 4. LA PROTECCIÓN DEL GRADO ACADÉMICO (DATOS EH 2025)

Existe una correlación inversa directa entre el nivel académico alcanzado y la probabilidad de caer en el subempleo:

| Grado Académico Aprobado | Total Muestra | PEA | Ocupados | Desocupados | Tasa Desempleo | Ejercen | Subempleados | % Subempleo en Ocupados |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Técnico Medio** | 516 | 426 | 407 | 19 | 4.5% | 95 | 312 | **76.7%** |
| **Técnico Superior** | 1.125 | 960 | 915 | 45 | 4.7% | 258 | 657 | **71.8%** |
| **Licenciatura** | 4.300 | 3.676 | 3.417 | 259 | **7.0%** | 1.930 | 1.487 | **43.5%** |
| **Diplomado** | 232 | 211 | 203 | 8 | 3.8% | 146 | 57 | **28.1%** |
| **Maestría** | 217 | 193 | 189 | 4 | 2.1% | 158 | 31 | **16.4%** |
| **Doctorado (Ph.D.)** | 32 | 25 | 24 | 1 | 4.0% | 20 | 4 | **16.7%** |

![Subempleo por Grado](grafico_subempleo_por_grado_2025.png)

> **Hallazgo:** El posgrado actúa como una barrera efectiva de protección laboral. Mientras más de **7 de cada 10 técnicos (medios y superiores)** están subempleados, menos de **3 de cada 10 profesionales con maestría o doctorado** sufren inadecuación ocupacional.

---

## 5. DÓNDE SE PIERDE EL TALENTO: RAMAS Y OFICIOS DE REFUGIO

### 5.1 Principales Ramas Económicas de Absorción Precaria (CAEB)
De los 2.548 profesionales subempleados en la muestra de 2025:

| Rama de Actividad Económica | Titulados Absorbidos (Muestra) | % del Total de Subempleados |
| :--- | :---: | :---: |
| **Comercio al por mayor y menor, reparación automotriz** | **799** | **31.4%** |
| **Industria Manufacturera** | 310 | 12.2% |
| **Transporte y Almacenamiento** | 239 | 9.4% |
| **Alojamiento y Servicios de Comida (Gastronomía)** | 194 | 7.6% |
| **Administración Pública y Seguridad Social** | 188 | 7.4% |
| **Agricultura, Ganadería y Silvicultura** | 172 | 6.8% |
| **Construcción** | 133 | 5.2% |
| **Otras ramas combinadas** | 513 | 20.0% |

![Ramas de Refugio](grafico_ramas_refugio_subempleo.png)

### 5.2 Los 10 Oficios Concretos Más Comunes entre Profesionales Subempleados (COB 2023)
1. **Vendedores de tiendas y almacenes comerciales:** 358 casos
2. **Vendedores de quioscos, mercados y ferias:** 134 casos
3. **Conductores de automóviles, taxis, trufis y camionetas:** 112 casos
4. **Mecánicos de mantenimiento y reparación automotriz:** 108 casos
5. **Secretarios y asistentes administrativos generales:** 63 casos
6. **Guardias de seguridad y vigilantes privados:** 56 casos
7. **Cocineros y manipuladores de alimentos:** 56 casos
8. **Auxiliares de almacenes e inventarios:** 53 casos
9. **Modistas, costureros y sastres:** 49 casos
10. **Cajeros de comercio y boleteros:** 46 casos

---

## 6. CONCLUSIONES PARA POLÍTICAS PÚBLICAS Y PLANIFICACIÓN MUNICIPAL (PTDI / PAD)

1. **Falso diagnóstico del desempleo:** Evaluar el éxito de la política educativa o laboral fijándose solo en la tasa de desempleo (5.8%) es un error; la verdadera pérdida social y económica está en el **50% de graduados que no ejercen**.
2. **Saturación técnica sin demanda articulada:** Las carreras técnicas comerciales (secretariado, contabilidad, mecánica) presentan más de un 70% de subempleo. Los municipios y gobernaciones deben vincular la oferta de institutos a las cadenas productivas reales de cada región.
3. **Incentivo al posgrado de especialidad:** Dado que la maestría reduce el subempleo a solo 16.4%, se deben crear fondos concursables de becas de posgrado orientados a ciencia aplicada e industria.
4. **Oficinas de Intermediación y Empleo Juvenil:** Urge que los gobiernos autónomos departamentales y municipales establezcan bolsas activas de empleo que reconecten a los licenciados que hoy manejan taxis o atienden tiendas con proyectos de infraestructura y servicios locales.
